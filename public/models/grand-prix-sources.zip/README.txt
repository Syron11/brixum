Grand Prix Racer (42000-1), Oh-Seong KWON. OMR preparation: technicbasics.
https://library.ldraw.org/omr/sets/892
Model: CC BY 2.0. Parts: see individual !LICENSE, Author and !HISTORY headers.
Converted to GLB for BRIXUM; drawing edge lines removed; meshes merged by material.
Conversion does not simplify geometry or substitute colours. The web GLB is subsequently meshopt-optimized with -si 0.5 -se 0.0005. Original source files retained here.
